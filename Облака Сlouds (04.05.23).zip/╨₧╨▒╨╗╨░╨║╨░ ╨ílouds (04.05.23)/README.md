# Clouds
<img src="preview.gif" width="300" />

Animated Clouds wallpaper for [Lively Wallpaper](https://github.com/rocksdanister/lively)

[Download](https://github.com/rocksdanister/clouds/releases)

[Live Demo](https://www.rocksdanister.com/clouds)

#### Features
- Cloud customization.
- Fog customization.
- Framerate control.
- Display scaling.